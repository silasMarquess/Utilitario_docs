#include <stdio.h>

// Definição da struct Endereco
struct Endereco {
    char rua[100];
    int numero;
    char cidade[50];
};

// Definição da struct Pessoa
struct Pessoa {
    char nome[50];
    int idade;
    float peso;
    float altura;
    struct Endereco endereco;
};

int main() {
    // Criação de uma instância da struct Pessoa
    struct Pessoa pessoa1;

    // Solicitando e lendo os valores dos campos da struct Pessoa e Endereco
    printf("Digite o nome: ");
    scanf("%49s", pessoa1.nome);

    printf("Digite a idade: ");
    scanf("%d", &pessoa1.idade);

    printf("Digite a rua: ");
    scanf("%99s", pessoa1.endereco.rua);

    printf("Digite o número: ");
    scanf("%d", &pessoa1.endereco.numero);

    printf("Digite a cidade: ");
    scanf("%49s", pessoa1.endereco.cidade);

    // Exibindo os valores
    printf("\nNome: %s\n", pessoa1.nome);
    printf("Idade: %d\n", pessoa1.idade);
    printf("Endereço: %s, %d, %s\n", pessoa1.endereco.rua, pessoa1.endereco.numero, pessoa1.endereco.cidade);

    return 0;
}
