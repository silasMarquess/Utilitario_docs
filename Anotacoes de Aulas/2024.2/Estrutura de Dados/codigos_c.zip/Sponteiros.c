#include <stdio.h>
#include <string.h>

// Definição da struct Pessoa
struct Pessoa {
    char nome[50];
    int idade;
    float peso;
};

int main() {
    // Criação de uma instância da struct Pessoa
    struct Pessoa pessoa1;
    struct Pessoa *p;

    // Apontando o ponteiro p para pessoa1
    p = &pessoa1;

    // Solicitando e lendo os valores dos campos da struct usando o ponteiro
    printf("Digite o nome: ");
    scanf("%49s", &pessoa1.nome);

    printf("Digite a idade: ");
    scanf("%d", &p->idade);

    printf("Digite o peso (em kg): ");
    scanf("%f", &p->peso);

    // Exibindo os valores usando o ponteiro
    printf("\nNome: %s\n", p->nome);
    printf("Nome: %s\n", pessoa1.nome);
    printf("\nIdade: %d\n", p->idade);
    printf("Idade: %d\n", pessoa1.idade);
    printf("\nPeso: %.2f kg\n", p->peso);
    printf("Peso: %.2f kg\n", pessoa1.peso);


    return 0;
}
