#include <stdio.h>

int main() {
    int x;
    int *p;

    // Apontando p para o endereço de x
    p = &x;

    // Solicitando e lendo o valor de x
    printf("Digite um valor para x: ");
    scanf("%d", &x);

    // Exibindo o valor de x e o valor apontado por p
    printf("Valor de x: %d\n", x);
    printf("Valor apontado por p: %d\n", *p);
    printf("Endereço de x: %x \n", &x);
    printf("Valor de P: %x \n", p);


    // Modificando o valor de x via ponteiro
    printf("Digite um novo valor para x (através do ponteiro): ");
    scanf("%d", p);

    // Exibindo o novo valor de x e o valor apontado por p
    printf("Novo valor de x: %d\n", x);
    printf("Novo valor apontado por p: %d\n", *p);
    printf("Endereço de p: %x \n", &p);
    printf("Valor de P: %x \n", p);
    return 0;
}
