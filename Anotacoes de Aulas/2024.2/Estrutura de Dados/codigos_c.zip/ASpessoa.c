#include <stdio.h>

// Definição da struct Pessoa
struct Pessoa {
    char nome[50];
    int idade;
    float peso;
};

int main() {
    //variavel contadora para o array de structs
    int c; 

    printf("Quantas registros serão criados: ");
    scanf("%d", &c);

    // Criação de um array de struct Pessoa
    struct Pessoa pessoas[c];

    // Lendo e atribuindo valores para as três pessoas
    for (int i = 0; i < c; i++) {
        printf("Digite o nome da pessoa %d: ", i + 1);
        scanf("%49s", pessoas[i].nome);

        printf("Digite a idade da pessoa %d: ", i + 1);
        scanf("%d", &pessoas[i].idade);

        printf("Digite o peso da pessoa %d (em kg): ", i + 1);
        scanf("%f", &pessoas[i].peso);

        printf("\n");
    }

    // Exibindo os valores do array de structs
    for (int i = 0; i < c; i++) {
        printf("Pessoa %d:\n", i + 1);
        printf("Nome: %s\n", pessoas[i].nome);
        printf("Idade: %d\n", pessoas[i].idade);
        printf("Peso: %.2f kg\n\n", pessoas[i].peso);
    }

    return 0;
}
