#include <stdio.h>
#include <string.h>

// Definição da struct Pessoa
struct Pessoa {
    char nome[50];
    int idade;
    float peso;
    float altura;
};

int main() {
    // Criação de uma instância da struct Pessoa
    struct Pessoa pessoa1;

    // Atribuindo valores ao primeiro elemento
    //strcpy(pessoa1.nome, "Vanessa");
    // Solicitando e lendo os valores dos campos da struct
    printf("Digite o nome: ");
    scanf("%49s", pessoa1.nome);  // Limitando o input a 49 caracteres

    printf("Digite a idade: ");
    scanf("%d", &pessoa1.idade);

    printf("Digite o peso (em kg): ");
    scanf("%f", &pessoa1.peso);

    // Exibindo os valores
    printf("\nNome: %s\n", pessoa1.nome);
    printf("Idade: %d\n", pessoa1.idade);
    printf("Peso: %.2f kg\n", pessoa1.peso);

    return 0;
}
