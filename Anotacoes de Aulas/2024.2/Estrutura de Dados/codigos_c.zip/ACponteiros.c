#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definição da struct Pessoa
struct Pessoa {
    char nome[50];
    int idade;
    float peso;
};

int main() {
    // Alocando memória dinamicamente para uma struct Pessoa
    struct Pessoa *p = (struct Pessoa *)malloc(sizeof(struct Pessoa));

    if (p == NULL) {
        printf("Erro na alocação de memória\n");
        return 1;
    }

    // Solicitando e lendo os valores dos campos usando o ponteiro
    printf("Digite o nome: ");
    scanf("%49s", p->nome);

    printf("Digite a idade: ");
    scanf("%d", &p->idade);

    printf("Digite o peso (em kg): ");
    scanf("%f", &p->peso);

// Exibindo os valores usando o ponteiro
    printf("\nNome: %s\n", p->nome);
    printf("Idade: %d\n", p->idade);
    printf("Peso: %.2f kg\n", p->peso);

    // Liberando a memória alocada
    free(p);

    return 0;
}

