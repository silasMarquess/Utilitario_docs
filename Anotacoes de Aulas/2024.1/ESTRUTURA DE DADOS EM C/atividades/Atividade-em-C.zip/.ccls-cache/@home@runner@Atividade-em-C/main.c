#include "MinhasLib/questionario.h"
#include <stdio.h>
#include <stdlib.h>

int main(void) {
  Q10();
  system("Pause");
  return 0;
}