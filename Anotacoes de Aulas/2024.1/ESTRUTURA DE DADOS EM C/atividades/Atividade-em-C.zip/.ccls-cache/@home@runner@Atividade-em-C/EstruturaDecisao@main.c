#include <stdio.h>
#include <stdlib.h>


int main(){
  int dia;
  printf("Informe um numero da semana");
  scanf("%d", &dia);
  


  
  system("pause");
  return 0;
}